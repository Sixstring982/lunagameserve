java -Djava.library.path=lib/linux/64 -jar out/artifacts/yazg_jar/yazg_jar.jar
