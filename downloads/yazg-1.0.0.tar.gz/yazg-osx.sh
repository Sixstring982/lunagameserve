java -Djava.library.path=lib/osx -jar out/artifacts/yazg_jar/yazg_jar.jar
