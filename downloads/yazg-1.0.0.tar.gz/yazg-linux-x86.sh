java -Djava.library.path=lib/linux/32 -jar out/artifacts/yazg_jar/yazg_jar.jar
